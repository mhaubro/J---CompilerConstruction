//(.*)

//The package
package pass;

//The import
import java.lang.System;

//The class
public class HelloWorld {

	//A public static method 
    public static String message() {
    	//A return statement
        return "Hello, World!";
    }

	//The main method
    public static void main(String[] args) {
    	//Printing on console
        System.out.println(HelloWorld.message());
    //A closed curly bracket     
    }
//Another closed curly bracket     
}